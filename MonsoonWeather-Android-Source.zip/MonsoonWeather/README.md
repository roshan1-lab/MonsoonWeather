# Monsoon Weather (Android)

Native Kotlin + Jetpack Compose weather app inspired by the supplied screenshot.

## Included
- Current conditions, hourly outlook, six-day forecast, and city search
- Optional phone location permission (uses the most recent Android location fix; manual city search remains available)
- US AQI and category label from Open-Meteo Air Quality API
- Embedded precipitation radar using RainViewer radar tiles and OpenStreetMap base tiles
- Refresh button and Open-Meteo attribution

## Build APK
1. Install Android Studio stable with Android SDK Platform 35.
2. Open this folder in Android Studio and let Gradle sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Data services and notes
- Forecast: https://open-meteo.com/en/docs
- Air quality: https://open-meteo.com/en/docs/air-quality-api
- Geocoding: https://open-meteo.com/en/docs/geocoding-api
- Radar: https://www.rainviewer.com/api.html
- Base map: OpenStreetMap

Open-Meteo's free API is intended for non-commercial use; review its current terms and required attribution before release. Radar availability and tile format depend on RainViewer's current API. The GPS action uses the latest known location available to Android; if none exists, turn on device Location and retry. For production, replace this with a current-location request flow and add robust API/radar error states.

## Current limitations
This is a build-ready Android Studio source project, not a compiled APK. AQI uses the US AQI scale. UV and current weather are forecast-provider values and may not match a nearby physical station.
