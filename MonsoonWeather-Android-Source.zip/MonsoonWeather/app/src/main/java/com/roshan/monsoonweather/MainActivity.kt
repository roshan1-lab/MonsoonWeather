package com.roshan.monsoonweather

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val page = Color(0xFFF0F1F3)
private val panel = Color(0xFFECE3DF)
private val accent = Color(0xFFFF9D4D)
private val brown = Color(0xFF795850)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { WeatherScreen() } }
    }
}

data class Weather(
    val city: String, val temp: Int, val feels: Int, val high: Int, val low: Int,
    val description: String, val humidity: Int, val pressure: Double, val wind: Double,
    val precipitation: Double, val uv: Double, val hourlyTimes: List<String>,
    val hourlyTemps: List<Int>, val hourlyRain: List<Int>,
    val days: List<String>, val highs: List<Int>, val lows: List<Int>, val aqi: Int, val latitude: Double, val longitude: Double
)

private fun fetchWeather(cityInput: String): Weather {
    val city = cityInput.trim().ifBlank { "Tadong, Sikkim" }
    val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(city, "UTF-8") + "&count=1&language=en&format=json"
    val geo = JSONObject(URL(geoUrl).readText())
    val results = geo.optJSONArray("results")
    val item = if (results != null && results.length() > 0) results.getJSONObject(0) else
        JSONObject("""{"name":"Tadong","admin1":"Sikkim","latitude":27.33,"longitude":88.61,"timezone":"Asia/Kolkata"}""")
    val lat = item.getDouble("latitude"); val lon = item.getDouble("longitude")
    val place = item.optString("name") + (item.optString("admin1").takeIf { it.isNotBlank() }?.let { ", $it" } ?: "")
    val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m" +
        "&hourly=temperature_2m,precipitation_probability,uv_index" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=7&timezone=auto"
    val j = JSONObject(URL(url).readText())
    val cur = j.getJSONObject("current")
    val daily = j.getJSONObject("daily")
    val hourly = j.getJSONObject("hourly")
    val code = cur.optInt("weather_code")
    val desc = when (code) {
        0 -> "Clear sky"; 1, 2 -> "Mostly sunny"; 3 -> "Cloudy"; 45, 48 -> "Foggy"
        51, 53, 55, 61, 63, 65 -> "Rain showers"; 71, 73, 75 -> "Snow"
        80, 81, 82 -> "Rain showers"; 95, 96, 99 -> "Thunderstorms"
        else -> "Pleasant with spells of sunshine"
    }
    val times = hourly.getJSONArray("time")
    val temps = hourly.getJSONArray("temperature_2m")
    val rain = hourly.getJSONArray("precipitation_probability")
    val hourLabels = mutableListOf<String>(); val hourTemps = mutableListOf<Int>(); val hourRain = mutableListOf<Int>()
    val now = System.currentTimeMillis()
    for (i in 0 until times.length()) {
        val time = times.getString(i)
        val parsed = runCatching { SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(time)?.time ?: 0L }.getOrDefault(0L)
        if (parsed >= now - 3600000 && hourLabels.size < 6) {
            hourLabels.add(runCatching { SimpleDateFormat("h a", Locale.US).format(Date(parsed)) }.getOrDefault(time))
            hourTemps.add(temps.optDouble(i).toInt()); hourRain.add(rain.optDouble(i).toInt())
        }
    }
    val dateArr = daily.getJSONArray("time"); val highsArr = daily.getJSONArray("temperature_2m_max"); val lowsArr = daily.getJSONArray("temperature_2m_min")
    val days = mutableListOf<String>(); val highs = mutableListOf<Int>(); val lows = mutableListOf<Int>()
    for (i in 0 until minOf(6, dateArr.length())) {
        days.add(runCatching { SimpleDateFormat("EEE", Locale.US).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dateArr.getString(i))!!) }.getOrDefault(dateArr.getString(i)))
        highs.add(highsArr.optDouble(i).toInt()); lows.add(lowsArr.optDouble(i).toInt())
    }
    val airUrl = "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$lat&longitude=$lon&current=us_aqi,european_aqi,pm2_5,pm10&timezone=auto"
    val air = runCatching { JSONObject(URL(airUrl).readText()).optJSONObject("current") }.getOrNull()
    val aqi = air?.optInt("us_aqi", -1) ?: -1
    return Weather(place, cur.optDouble("temperature_2m").toInt(), cur.optDouble("apparent_temperature").toInt(),
        highs.firstOrNull() ?: cur.optDouble("temperature_2m").toInt(), lows.firstOrNull() ?: 0, desc,
        cur.optInt("relative_humidity_2m"), cur.optDouble("pressure_msl"), cur.optDouble("wind_speed_10m"),
        cur.optDouble("precipitation"), hourly.getJSONArray("uv_index").optDouble(0),
        hourLabels, hourTemps, hourRain, days, highs, lows, aqi, lat, lon)
}

@Composable
fun WeatherScreen() {
    var cityQuery by remember { mutableStateOf("Tadong, Sikkim") }
    var city by remember { mutableStateOf("Tadong, Sikkim") }
    var weather by remember { mutableStateOf<Weather?>(null) }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var gpsMessage by remember { mutableStateOf("") }
    val activity = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    fun refreshCoordinates(lat: Double, lon: Double) {
        loading = true; error = ""
        scope.launch {
            try { weather = withContext(Dispatchers.IO) { fetchWeatherAt(lat, lon) }; cityQuery = weather?.city ?: cityQuery }
            catch (e: Exception) { error = "Could not load local weather. Check your internet and try again." }
            finally { loading = false }
        }
    }
    fun refresh(name: String = cityQuery) {
        cityQuery = name; loading = true; error = ""
        scope.launch {
            try { weather = withContext(Dispatchers.IO) { fetchWeather(name) }; city = weather?.city ?: name }
            catch (e: Exception) { error = "Could not load weather. Check your internet and try again." }
            finally { loading = false }
        }
    }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) {
            val manager = activity.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            val loc = runCatching {
                listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
                    .mapNotNull { provider ->
                        val enabled = runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false)
                        val allowed = ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                            ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (enabled && allowed) manager.getLastKnownLocation(provider) else null
                    }.maxByOrNull { it.time }
            }.getOrNull()
            if (loc != null) {
                gpsMessage = "Using your phone location"
                refreshCoordinates(loc.latitude, loc.longitude)
            } else gpsMessage = "No recent location found. Turn on Location and try again."
        } else gpsMessage = "Location permission denied. You can still search for a city."
    }
    LaunchedEffect(Unit) { refresh() }
    Column(Modifier.fillMaxSize().background(page).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { refresh() }) { Text("↻ Refresh", color = brown, fontSize = 16.sp) }
        }
        OutlinedButton(onClick = {
            val fine = ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (fine || coarse) {
                val manager = activity.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
                val loc = runCatching { listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER).mapNotNull { provider -> if (manager.isProviderEnabled(provider)) manager.getLastKnownLocation(provider) else null }.maxByOrNull { it.time } }.getOrNull()
                if (loc != null) refreshCoordinates(loc.latitude, loc.longitude) else gpsMessage = "Turn on Location and try again to get a recent fix."
            } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }, modifier = Modifier.fillMaxWidth()) { Text("◎ Use my phone location") }
        if (gpsMessage.isNotBlank()) Text(gpsMessage, fontSize = 12.sp, color = brown, modifier = Modifier.padding(top = 4.dp))
        OutlinedTextField(value = cityQuery, onValueChange = { cityQuery = it },
            label = { Text("Search city or town") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp))
        Button(onClick = { refresh(cityQuery) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            colors = ButtonDefaults.buttonColors(containerColor = brown)) { Text("Get weather") }
        Spacer(Modifier.height(28.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = accent)
        if (error.isNotBlank()) Text(error, color = Color.Red, modifier = Modifier.padding(12.dp))
        val w = weather
        if (w != null) {
            Text(w.city, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${w.temp}°", fontSize = 62.sp, fontWeight = FontWeight.Medium, color = Color.Black)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(w.description, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("${w.low}°–${w.high}°  Feels like ${w.feels}°", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(24.dp))
            CardBlock("Current conditions") {
                Row(Modifier.fillMaxWidth()) {
                    Metric("Humidity", "${w.humidity}%", Modifier.weight(1f)); Spacer(Modifier.width(10.dp)); Metric("UV index", "%.1f".format(w.uv), Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth()) {
                    Metric("Precipitation", "${w.precipitation} mm", Modifier.weight(1f)); Spacer(Modifier.width(10.dp)); Metric("Pressure", "${w.pressure.toInt()} hPa", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth()) { Metric("Wind", "${w.wind.toInt()} km/h", Modifier.weight(1f)); Spacer(Modifier.width(10.dp)); Metric("US AQI", if (w.aqi >= 0) "${w.aqi} · ${aqiText(w.aqi)}" else "Unavailable", Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(22.dp))
            CardBlock("Weather today") { Text(w.description, color = Color.DarkGray, fontSize = 17.sp) }
            Spacer(Modifier.height(22.dp))
            CardBlock("Hourly forecast") {
                Text("Updated from Open-Meteo", color = Color.DarkGray, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    items(w.hourlyTimes.size) { i ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(48.dp)) {
                            Text(w.hourlyTimes[i], fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("☀", fontSize = 25.sp, color = accent)
                            Text("${w.hourlyTemps[i]}°", fontSize = 17.sp)
                            Text("${w.hourlyRain[i]}%", color = Color.Gray, fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            CardBlock("6-DAY FORECAST") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    w.days.indices.forEach { i ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(w.days[i], fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp)); Text("☀", color = accent, fontSize = 22.sp)
                            Text("${w.highs[i]}°", fontSize = 15.sp)
                            Text("${w.lows[i]}°", color = Color.Gray, fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            CardBlock("Weather radar") {
                Text("Live precipitation radar", color = Color.DarkGray, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                RadarMap(w.latitude, w.longitude)
                Text("Radar tiles by RainViewer · Map © OpenStreetMap", fontSize = 11.sp, color = brown)
            }
            Spacer(Modifier.height(22.dp))
            Text("Weather data by Open-Meteo.com · Air quality by Open-Meteo", fontSize = 13.sp, color = brown,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 24.dp))
        }
    }
}

@Composable
private fun CardBlock(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(28.dp)).padding(22.dp)) {
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Spacer(Modifier.height(16.dp))
        content()
    }
}

@Composable
private fun Metric(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFFF3EFED), RoundedCornerShape(22.dp)).padding(14.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Text(value, fontSize = 17.sp, color = if (title == "Humidity") Color(0xFF328444) else Color.DarkGray)
    }
}
